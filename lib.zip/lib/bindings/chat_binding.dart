import 'package:feeling_sync_chat/controllers/chat_controller.dart';
import 'package:get/get.dart';

class ChatBinding extends Bindings {
  @override
  void dependencies() {
    // Retrieve chatId from route parameters
    int? chatId = int.tryParse(Get.parameters['id'] ?? '');

    if (chatId != null && chatId > 0) {
      Get.put(
        ChatController(chatId: chatId),
        tag: chatId.toString(),
      );
    } else {
      print("Error: Invalid chat ID provided in route parameters.");
      // Consider handling this case in the UI instead of showing a snackbar here.
    }
  }
}
