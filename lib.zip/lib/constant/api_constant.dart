class ApiConstants {
  static const String baseUrl = 'http://192.168.100.94:5000';
  // static const String baseUrl = 'https://c98a-185-132-178-67.ngrok-free.app';
  static const String wsUrl = 'ws://192.168.100.94:5000';
  
}