import 'package:feeling_sync_chat/views/bottom%20navigation%20bar%20pages/notification_page.dart';
import 'package:feeling_sync_chat/views/bottom%20navigation%20bar%20pages/home_page.dart';
import 'package:feeling_sync_chat/constant/api_constant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:convert';

class BottomNavigationBarrController extends GetxController {
  var currentTab = 0.obs;
  final List<Widget> screens = [
    HomePage(),
    NotificationPage(),
  ];

  Future<String?> _getAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');
    print('Retrieved Token: $token');
    return token;
  }

  // Fetch friend's name by ID
  Future<String?> fetchFriendName(String friendName) async {
    final token = await _getAuthToken();
    if (token == null) return "User is not authenticated";

    final url = Uri.parse("${ApiConstants.baseUrl}/api/users/search");

    try {
      final response = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({'name': friendName}),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        if (data.isNotEmpty) {
          return data[0]['name']; // ارجع فقط الاسم
        }
        return "No users found";
      } else {
        return "Server error: ${response.statusCode}";
      }
    } catch (e) {
      return "Network error: $e";
    }
  }

  // Send a friend request
  Future<String> sendFriendRequest(String friendName) async {
    final token = await _getAuthToken();
    if (token == null) return "User is not authenticated";

    final url = Uri.parse("${ApiConstants.baseUrl}/api/friends/request");

    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode(
          {'friend_name': friendName}), // Assuming backend supports friend_name
    );

    print("Response Body: ${response.body}");

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['message']; // Success message
    } else if (response.statusCode == 400) {
      final error = jsonDecode(response.body);
      return error['message'] ?? "An error occurred";
    } else {
      return "An error occurred";
    }
  }



}
