import 'package:feeling_sync_chat/constant/api_constant.dart';
import 'package:feeling_sync_chat/services/pusher_service.dart';
import 'package:feeling_sync_chat/services/api_service.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ChatController extends GetxController {
  final RxList<Message> messages = <Message>[].obs;
  final RxBool isLoading = false.obs;
  final int chatId;

  // Reactively managed current user ID
  final RxInt currentUserId = 0.obs;

  final ApiService _apiService = ApiService();
  final PusherService _pusherService = PusherService();

  ChatController({required this.chatId});

  @override
  void onInit() {
    super.onInit();
    if (chatId == 0) {
      Get.snackbar("Error", "Invalid chat ID.");
      return;
    }
    loadMessages();
  }

  @override
  void onReady() {
    super.onReady();
    _initPusher();
  }

  void _initPusher() {
    _pusherService.subscribeToPrivateChannel('chat.$chatId');
    _pusherService.bindEvent('new-message', (data) {
      try {
        final message = Message.fromJson(data);
        messages.add(message);
      } catch (e) {
        print("Error processing new-message event: $e");
      }
    });
  }

  Future<void> loadMessages() async {
    if (chatId == 0) {
      Get.snackbar("Error", "Cannot load messages for invalid chat.");
      return;
    }
    isLoading.value = true;

    try {
      final response =
          await _apiService.get('/api/private-chat/$chatId/messages');

      if (response.data is Map && response.data.containsKey("messages")) {
        messages.value = (response.data['messages'] as List)
            .map((json) => Message.fromJson(json))
            .toList();

        if (response.data.containsKey("current_user_id")) {
          currentUserId.value = response.data['current_user_id'];
        }
      }
    } catch (e) {
      print("Error loading messages: $e");
      Get.snackbar("Error", "Failed to load messages.");
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> sendMessage(String content) async {
    if (chatId == 0) {
      Get.snackbar("Error", "Invalid chat ID. Cannot send message.");
      return;
    }

    if (content.trim().isEmpty) {
      Get.snackbar("Error", "Message cannot be empty.");
      return;
    }

    try {
      // Step 1: Add message locally with pending sentiment
      final tempMessage = Message(
        id: DateTime.now().millisecondsSinceEpoch,
        userId: currentUserId.value,
        content: content,
        createdAt: DateTime.now(),
        sentiment: 'Analyzing...',
      );

      messages.add(tempMessage);

      // Step 2: Perform sentiment analysis via Python API
      String sentiment = 'Analysis failed';
      try {
        final sentimentResponse = await http
            .post(
              Uri.parse('http://192.168.100.94:5002/analyze'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'text': content}),
            )
            .timeout(const Duration(seconds: 60));

        if (sentimentResponse.statusCode == 200) {
          final sentimentData = jsonDecode(sentimentResponse.body);
          sentiment = sentimentData['sentiment'] ?? 'Neutral';
        }
      } catch (e) {
        print("[Chat] Sentiment analysis failed: $e");
      }

      // Step 3: Send message to Laravel backend with sentiment
      final response =
          await _apiService.post('/api/private-chat/send-message', {
        'content': content,
        'private_chat_id': chatId,
        'sentiment': sentiment,
      });

      if (response.data != null && response.data.containsKey("data")) {
        final messageData = Message.fromJson(response.data['data']);

        // Update pending message with real message data
        messages[messages.indexWhere((m) => m.id == tempMessage.id)] =
            messageData;
      }
    } catch (e) {
      print("Error sending message: $e");
      Get.snackbar("Error", "Failed to send message.");
    }
  }

  Future<void> clearMessages() async {
    if (chatId == 0) {
      Get.snackbar("Error", "Invalid chat ID.");
      return;
    }

    try {
      final response = await _apiService.delete(
        '${ApiConstants.baseUrl}/api/private-chat/$chatId/clear-messages',
      );

      if (response.statusCode == 200) {
        messages.clear();
        Get.snackbar("Success", "All messages cleared.");
      } else {
        Get.snackbar("Error", "Failed to clear messages.");
      }
    } catch (e) {
      print("Error clearing messages: $e");
      Get.snackbar("Error", "Could not clear messages.");
    }
  }

  Future<void> deleteMessage(int messageId) async {
    try {
      final response = await _apiService.delete('${ApiConstants.baseUrl}/api/messages/$messageId');

      if (response.statusCode == 200) {
        // Remove the message from the observable list
        messages.removeWhere((m) => m.id == messageId);
        Get.snackbar("Success", "Message deleted successfully.");
      } else {
        Get.snackbar("Error", "Failed to delete message.");
      }
    } catch (e) {
      print("Error deleting message: $e");
      Get.snackbar("Error", "An error occurred while deleting the message.");
    }
  }
}

class Message {
  final int id;
  final int userId;
  final String content;
  final DateTime createdAt;
  final String sentiment;

  Message({
    required this.id,
    required this.userId,
    required this.content,
    required this.createdAt,
    this.sentiment = "Neutral",
  });

  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: json['id'],
      userId: json['user_id'],
      content: json['content'] ?? '',
      createdAt: DateTime.parse(json['created_at']),
      sentiment: json['sentiment'] ?? "Neutral",
    );
  }
}
