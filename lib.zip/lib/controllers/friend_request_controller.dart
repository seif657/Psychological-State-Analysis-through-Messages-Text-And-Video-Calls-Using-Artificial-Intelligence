import 'package:feeling_sync_chat/constant/api_constant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';


class FriendRequestController {
  Future<String?> _getAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');
    print('Retrieved Token: $token');
    return token;
  }

  Future<List<Map<String, dynamic>>> getIncomingRequests() async {
    final token = await _getAuthToken();
    if (token == null) throw Exception('User is not authenticated');

    final response = await http.get(
      Uri.parse('${ApiConstants.baseUrl}/api/friends/incoming'),
      headers: {
        'Authorization': 'Bearer $token',
        'Accept': 'application/json',
      },
    );

    // Debugging API response
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode == 200) {
      try {
        final List<dynamic> data = json.decode(response.body);
        return data
            .map((item) {
              // Updated to match the field names in your API response
              final userId = item['id'];
              final userName = item['name'];
              if (userId == null || userName == null) {
                print('Invalid item skipped: $item');
                return null;
              }
              return {
                'id': int.tryParse(userId.toString()) ?? 0,
                'name': userName.toString(),
              };
            })
            .whereType<Map<String, dynamic>>() // Removes null entries
            .toList();
      } catch (e) {
        throw Exception('Failed to parse response: $e');
      }
    } else {
      throw Exception(
          'Failed to load friend requests. Status: ${response.statusCode}');
    }
  }

  Future<bool> acceptRequest(int userId) async {
    final token = await _getAuthToken();
    if (token == null) throw Exception('User is not authenticated');

    final response = await http.post(
      Uri.parse('${ApiConstants.baseUrl}/api/friends/accept'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({'user_id': userId}),
    );

    print('Accept Request Response: ${response.body}');
    return response.statusCode == 200;
  }

  Future<bool> rejectRequest(int userId) async {
    final token = await _getAuthToken();
    if (token == null) throw Exception('User is not authenticated');

    final response = await http.post(
      Uri.parse('${ApiConstants.baseUrl}/api/friends/reject'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({'user_id': userId}),
    );

    print('Reject Request Response: ${response.body}');
    return response.statusCode == 200;
  }
}
