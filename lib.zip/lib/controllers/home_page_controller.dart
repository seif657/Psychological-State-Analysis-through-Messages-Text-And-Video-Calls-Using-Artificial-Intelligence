import 'package:feeling_sync_chat/constant/api_constant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import 'dart:convert';

class HomePageController extends GetxController {
  var acceptedFriends = <Map<String, dynamic>>[].obs;

  var isSearching = false.obs;
  var searchResult = Rxn<Map<String, dynamic>>();
  var searchError = ''.obs;

  Future<String?> _getAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');
    print('Retrieved Token: $token');
    return token;
  }

  Future<void> refreshAcceptedFriends() async {
    final token = await _getAuthToken();
    try {
      final response = await http.get(
        Uri.parse('${ApiConstants.baseUrl}/api/friends'),
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);

        for (var friend in data) {
          if (friend['chat_id'] == null) {
            try {
              int? chatId = await createChat(int.parse(friend['id'].toString()));
              if (chatId != null) {
                friend['chat_id'] = chatId;
              } else {
                print('Chat creation failed for friend ${friend['id']}');
              }
            } catch (e) {
              print('Error creating chat for friend ${friend['id']}: $e');
            }
          }
        }

        acceptedFriends.assignAll(List<Map<String, dynamic>>.from(data));
      } else {
        throw Exception('Failed to load accepted friends');
      }
    } catch (e) {
      Get.snackbar(
        "Error",
        "Failed to refresh friends: $e",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  Future<int?> createChat(int friendId) async {
    try {
      final url = '${ApiConstants.baseUrl}/api/private-chat/create';
      final token = await _getAuthToken();
      final headers = {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      };
      final body = jsonEncode({'friend_id': friendId});

      print('POST $url');
      print('Headers: $headers');
      print('Body: $body');

      final response = await http.post(
        Uri.parse(url),
        headers: headers,
        body: body,
      );

      print('Response: ${response.statusCode}, ${response.body}');

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = jsonDecode(response.body);
        if (data != null && data.containsKey('chat_id')) {
          return data['chat_id'];
        }
      }

      print('Chat creation failed. Response: ${response.body}');
      return null;
    } catch (e) {
      print('Exception in createChat: $e');
      return null;
    }
  }

  Future<void> searchFriend(String friendName) async {
    isSearching.value = true;
    searchResult.value = null;
    searchError.value = '';
    try {
      final token = await _getAuthToken();
      final response = await http.post(
        Uri.parse('${ApiConstants.baseUrl}/api/users/search'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'name': friendName}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data != null && data['friend'] != null) {
          // Ensure the id is converted to int
          final friend = data['friend'];
          friend['id'] = int.parse(friend['id'].toString());
          searchResult.value = friend;
        } else {
          searchError.value = "Friend not found";
        }
      } else {
        searchError.value = "Error: ${response.statusCode}";
      }
    } catch (e) {
      searchError.value = "Error searching friend: $e";
    } finally {
      isSearching.value = false;
    }
  }

  void clearSearch() {
    searchResult.value = null;
    searchError.value = '';
    isSearching.value = false;
  }

  @override
  void onClose() {
    super.onClose();
  }
}