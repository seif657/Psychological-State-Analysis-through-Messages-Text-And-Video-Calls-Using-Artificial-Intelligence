import 'package:feeling_sync_chat/constant/api_constant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import 'dart:convert';

class NotificationController extends GetxController {
  final RxList<Map<String, dynamic>> notifications =
      <Map<String, dynamic>>[].obs;
  // final PusherChannelsFlutter pusher = PusherChannelsFlutter();

  @override
  void onInit() {
    super.onInit();
    connectPusher();
  }

  Future<String?> _getAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  // Fetch notifications from the backend
  Future<void> fetchNotifications() async {
    try {
      final token = await _getAuthToken();
      if (token == null) throw Exception("Authentication token is missing.");

      final response = await http.get(
        Uri.parse('${ApiConstants.baseUrl}/api/notifications'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List<dynamic> notificationList = data['notifications'];
        notifications.assignAll(notificationList.map((notification) {
          return {
            'id': notification['id'],
            'user_id': notification['user_id'],
            'type': notification['type'],
            'content': notification['content'],
            'is_read': notification['is_read'],
            'created_at': notification['created_at'],
            'updated_at': notification['updated_at'],
          };
        }).toList());
      } else {
        throw Exception(
            'Failed to fetch notifications: ${response.statusCode}');
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to fetch notifications: $e',
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }

  // Clear all notifications
  Future<void> clearNotifications() async {
    try {
      final token = await _getAuthToken();
      if (token == null) throw Exception("Authentication token is missing.");

      final response = await http.delete(
        Uri.parse('${ApiConstants.baseUrl}/api/notifications'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        notifications.clear();
      } else {
        throw Exception(
            'Failed to clear notifications: ${response.statusCode}');
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to clear notifications: $e',
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }

  // Connect to Pusher and listen for real-time notifications
  void connectPusher() async {
    // try {
    //   final token = await _getAuthToken();
    //   if (token == null) throw Exception("Authentication token is missing.");

    //   await pusher.init(
    //     apiKey: "fe3fa23857331920409b", // Replace with your actual API key
    //     cluster: "us2", // Replace with your actual cluster
    //     onAuthorizer: (channelName, socketId, options) async {
    //       final response = await http.post(
    //         Uri.parse('${ApiConstants.baseUrl}/broadcasting/auth'),
    //         headers: {
    //           'Authorization': 'Bearer $token',
    //           'Content-Type': 'application/json',
    //         },
    //         body: jsonEncode(
    //             {'socket_id': socketId, 'channel_name': channelName}),
    //       );

    //       if (response.statusCode == 200) {
    //         return jsonDecode(response.body);
    //       } else {
    //         throw Exception("Failed to authorize channel: ${response.body}");
    //       }
    //     },
    //     onError: (message, code, error) => print("Pusher error: $message"),
    //     onConnectionStateChange: (currentState, previousState) {
    //       print("Connection state changed: $currentState");
    //     },
    //   );

    //   final notificationChannelName =
    //       "private-notifications.${await _getUserId()}";
    //   await pusher.subscribe(
    //     channelName: notificationChannelName,
    //     onEvent: (event) {
    //       print("Notification event received: ${event.data}");
    //       final notification = jsonDecode(event.data ?? '{}');
    //       notifications.insert(
    //           0, notification); // Add new notification to the top
    //     },
    //   );

    //   await pusher.connect();
    //   print("Connected to Pusher and subscribed to $notificationChannelName.");
    // } catch (e) {
    //   print("Error connecting to Pusher: $e");
    //   Get.snackbar(
    //     "Error",
    //     "Failed to connect to Pusher: $e",
    //     snackPosition: SnackPosition.BOTTOM,
    //   );
    // }
  }

  // Get the current user ID
  // ignore: unused_element
  Future<int> _getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('user_id') ?? 0;
  }


}
