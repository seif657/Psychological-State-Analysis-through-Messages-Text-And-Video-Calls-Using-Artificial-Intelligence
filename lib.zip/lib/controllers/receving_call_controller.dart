import 'package:feeling_sync_chat/services/webrtc_service.dart';
import 'package:feeling_sync_chat/constant/api_constant.dart';
import 'package:feeling_sync_chat/utils/auth_token.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart';

class ReceivingCallController extends GetxController {
  final isCallAccepted = false.obs;
  final webRTCService = WebRTCService();
  final Dio dio = Dio(); // Initialize Dio instance

  Future<void> acceptCall(String callId) async {
    try {
      final response = await dio.post(
        '${ApiConstants.baseUrl}/api/accept-call',
        data: {
          'call_id': callId,
        },
        options: Options(
          headers: {
            'Authorization': 'Bearer ${await getAuthToken()}',
          },
        ),
      );

      if (response.statusCode == 200) {
        isCallAccepted.value = true;
        webRTCService.initializePeerConnection();
        webRTCService
            .createAnswer(); // Ensure this method exists in WebRTCService
      }
    } catch (e) {
      print('Error accepting call: $e');
    }
  }

  Future<void> rejectCall(String callId) async {
    try {
      await dio.post(
        '${ApiConstants.baseUrl}/api/reject-call',
        data: {
          'call_id': callId,
        },
        options: Options(
          headers: {
            'Authorization': 'Bearer ${await getAuthToken()}',
          },
        ),
      );
    } catch (e) {
      print('Error rejecting call: $e');
    }
  }
}
