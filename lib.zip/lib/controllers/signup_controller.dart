import 'package:feeling_sync_chat/constant/api_constant.dart';
import 'package:feeling_sync_chat/views/bottom_navigation_bar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:convert';

class SignupController extends GetxController {
  final isLoading = false.obs;

  Future<void> signUp(String name, String email, String password) async {
    final url = Uri.parse('${ApiConstants.baseUrl}/api/registration');

    final userData = {'name': name, 'email': email, 'password': password};

    isLoading.value = true;

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(userData),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);

        if (responseData.containsKey('token')) {
          await saveAuthToken(responseData['token']);
          print('Token Saved: ${responseData['token']}');
        }

        Get.snackbar(
          'Success',
          responseData['message'] ?? 'Signup successful!',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green,
          colorText: Colors.white,
        );

        Get.offAll(() => BottomNavigationBarr());
      } else {
        final responseData = jsonDecode(response.body);
        Get.snackbar(
          'Error',
          responseData['message'] ?? 'An error occurred',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to connect to the server: ${e.toString()}',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> saveAuthToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    print('Saved Token: $token');
  }
}
