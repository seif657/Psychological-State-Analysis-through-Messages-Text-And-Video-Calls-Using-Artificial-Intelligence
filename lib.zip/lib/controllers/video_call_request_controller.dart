import 'package:pusher_client/pusher_client.dart' as pusher_lib;
import 'package:feeling_sync_chat/services/webrtc_service.dart';
import 'package:feeling_sync_chat/constant/api_constant.dart';
import 'package:feeling_sync_chat/utils/auth_token.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:get/get.dart';

class VideoCallRequestController extends GetxController {
  MediaStream? localStream;
  final isMuted = false.obs;
  final isCameraOff = false.obs;
  final isLoading = false.obs;
  final webRTCService = WebRTCService();
  final Dio dio = Dio();
  // late echo_lib.Echo<pusher_lib.PusherClient, echo_lib.PusherChannel> echo;
  late pusher_lib.PusherClient pusher;

  @override
  void onInit() {
    super.onInit();
    _initializeCamera();
    _initializePusher();
  }

  Future<void> _initializePusher() async {
    // ignore: unused_local_variable
    final authToken = await getAuthToken();

    // Initialize Pusher
    pusher = pusher_lib.PusherClient(
      'fe3fa23857331920409b', // Replace with your Pusher key
      pusher_lib.PusherOptions(
        cluster: 'us2', // Replace with your Pusher cluster
        encrypted: true,
      ),
      autoConnect: false,
    );

    // Initialize Laravel Echo with proper configuration
    // echo = echo_lib.Echo.pusher(
    //   'fe3fa23857331920409b',
    //   cluster: 'us2',
    //   authEndPoint: '${ApiConstants.baseUrl}/broadcasting/auth',
    //   authHeaders: {
    //     'Authorization': 'Bearer $authToken',
    //     'Content-Type': 'application/json',
    //   },
    //   encrypted: true,
    //   autoConnect: true,
    // ) as echo_lib.Echo<pusher_lib.PusherClient, echo_lib.PusherChannel>;

    // Connect to Pusher
    pusher.connect();
  }

  Future<void> _initializeCamera() async {
    try {
      isLoading.value = true;
      await webRTCService.initialize();
      localStream = webRTCService.localStream;
    } catch (e) {
      print('Error initializing camera: $e');
      Get.snackbar(
        'Error',
        'Failed to initialize camera',
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> initiateCall(String privateChatId, String callType) async {
    try {
      isLoading.value = true;
      final authToken = await getAuthToken();

      final response = await dio.post(
        '${ApiConstants.baseUrl}/api/start-call',
        options: Options(
          headers: {
            'Authorization': 'Bearer $authToken',
            'Content-Type': 'application/json',
          },
        ),
        data: {
          'private_chat_id': privateChatId,
          'call_type': callType,
        },
      );

      if (response.statusCode == 200) {
        await webRTCService.initializePeerConnection();
        await webRTCService.createOffer();

        // Listen for call acceptance on the private channel
        // echo.private('private-chat.$privateChatId').listen('WebRTCSignal',
        //     (dynamic e) {
        //   if (e.signal['type'] == 'call-accepted') {
        //     print('Call accepted by remote user');
        //     _handleCallAccepted(e.signal);
        //   }
        // });
      } else {
        Get.snackbar(
          'Error',
          'Failed to initiate call',
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    } catch (e) {
      print('Error initiating call: $e');
      Get.snackbar(
        'Error',
        'Failed to connect call',
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isLoading.value = false;
    }
  }

  // ignore: unused_element
  void _handleCallAccepted(Map<String, dynamic> signal) async {
    try {
      await webRTCService.handleRemoteDescription(signal['sdp']);
    } catch (e) {
      print('Error handling call acceptance: $e');
    }
  }

  void listenForIncomingCalls(String userId) {
    // echo.private('private-notifications.$userId').listen('NotificationReceived',
    //     (dynamic e) {
    //   if (e.notification['type'] == 'call-started') {
    //     _handleIncomingCall(e.notification);
    //   }
    // });
  }

  // ignore: unused_element
  void _handleIncomingCall(Map<String, dynamic> notification) {
    Get.dialog(
      AlertDialog(
        title: const Text('Incoming Call'),
        content: Text('${notification['content']}'),
        actions: [
          TextButton(
            onPressed: () {
              Get.back();
              _rejectCall(notification['call_id']);
            },
            child: const Text('Decline'),
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
          ),
          TextButton(
            onPressed: () {
              Get.back();
              _acceptCall(notification['call_id']);
            },
            child: const Text('Accept'),
            style: TextButton.styleFrom(
              foregroundColor: Colors.green,
            ),
          ),
        ],
      ),
      barrierDismissible: false,
    );
  }

  Future<void> _acceptCall(String callId) async {
    try {
      final authToken = await getAuthToken();
      final response = await dio.post(
        '${ApiConstants.baseUrl}/api/accept-call',
        options: Options(
          headers: {
            'Authorization': 'Bearer $authToken',
            'Content-Type': 'application/json',
          },
        ),
        data: {
          'call_id': callId,
        },
      );

      if (response.statusCode == 200) {
        await _initializeCamera();
        await webRTCService.initializePeerConnection();
        await webRTCService.createAnswer();
      }
    } catch (e) {
      print('Error accepting call: $e');
      Get.snackbar(
        'Error',
        'Failed to accept call',
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }

  Future<void> _rejectCall(String callId) async {
    try {
      final authToken = await getAuthToken();
      await dio.post(
        '${ApiConstants.baseUrl}/api/reject-call',
        options: Options(
          headers: {
            'Authorization': 'Bearer $authToken',
            'Content-Type': 'application/json',
          },
        ),
        data: {
          'call_id': callId,
        },
      );
    } catch (e) {
      print('Error rejecting call: $e');
    }
  }

  Future<void> endCall(String privateChatId) async {
    try {
      final authToken = await getAuthToken();
      webRTCService.dispose();

      await dio.post(
        '${ApiConstants.baseUrl}/api/end-call',
        options: Options(
          headers: {
            'Authorization': 'Bearer $authToken',
            'Content-Type': 'application/json',
          },
        ),
        data: {
          'private_chat_id': privateChatId,
        },
      );
    } catch (e) {
      print('Error ending call: $e');
    }
  }

  Future<void> sendSignal(
      String privateChatId, Map<String, dynamic> signal) async {
    try {
      final authToken = await getAuthToken();
      await dio.post(
        '${ApiConstants.baseUrl}/api/send-signal',
        data: {
          'private_chat_id': privateChatId,
          'signal': signal,
        },
        options: Options(
          headers: {
            'Authorization': 'Bearer $authToken',
            'Content-Type': 'application/json',
          },
        ),
      );
    } catch (e) {
      print('Error sending signal: $e');
    }
  }

  void toggleMute() {
    isMuted.value = !isMuted.value;
    localStream?.getAudioTracks().forEach((track) {
      track.enabled = !isMuted.value;
    });
  }

  void toggleCamera() {
    isCameraOff.value = !isCameraOff.value;
    localStream?.getVideoTracks().forEach((track) {
      track.enabled = !isCameraOff.value;
    });
  }

  @override
  void onClose() {
    webRTCService.dispose();
    pusher.disconnect();
    super.onClose();
  }
}
