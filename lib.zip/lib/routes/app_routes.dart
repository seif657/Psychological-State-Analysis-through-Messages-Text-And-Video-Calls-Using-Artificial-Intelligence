part of 'app_pages.dart';

abstract class Routes {
  static const HOME = '/home'; // Fixed to be a string
  static const CHAT = '/chat'; // Fixed to be a string
}
