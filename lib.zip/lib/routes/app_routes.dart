part of 'app_pages.dart';
abstract class Routes {
  static const HOME = '/'; // Fixed to be a string
  static const CHAT = '/chat'; // Fixed to be a string
}
