import 'package:feeling_sync_chat/constant/api_constant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:pusher_client/pusher_client.dart';

class PusherService {
  static final PusherService _instance = PusherService._internal();
  factory PusherService() => _instance;
  PusherService._internal();

  late PusherClient pusher;
  late Channel channel;

  // Retrieve the stored authentication token
  Future<String?> _getAuthToken() async {
    print("H1: Retrieving token...");
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');
    print("H2: Retrieved Token: $token");
    return token;
  }

  // Initialize Pusher with the necessary options and authentication
  Future<void> init() async {
    final token = await _getAuthToken();
    pusher = PusherClient(
      '78f7cee4050aca7ef0a4',
      PusherOptions(
        host: "192.168.100.94", // Make sure this IP is accessible from your device
        wsPort: 6001,           // Your WebSocket port
        cluster: 'us2',
        encrypted: true,
        auth: PusherAuth(
          '${ApiConstants.baseUrl}/broadcasting/auth',
          headers: {
            'Authorization': 'Bearer ${token ?? ""}',
            'Accept': 'application/json',
          },
        ),
      ),
    );

    pusher.connect();
    print("Pusher connected.");

    // Listen to connection state changes
    pusher.onConnectionStateChange((state) {
      print('Pusher connection state: ${state!.currentState}');
    });

    // Listen to connection errors
    pusher.onConnectionError((error) {
      print('Pusher connection error: ${error!.message}');
    });
  }

  // Subscribe to a private channel. For example, if channelName is "chat.4",
  // it will subscribe to "private-chat.4"
  void subscribeToPrivateChannel(String channelName) {
    print("Subscribing to channel: private-$channelName");
    channel = pusher.subscribe('private-$channelName');

    // Listen for successful subscription
    channel.bind('pusher:subscription_succeeded', (data) {
      print('Successfully subscribed to channel: private-$channelName');
    });

    // Listen for subscription errors
    channel.bind('pusher:subscription_error', (data) {
      print('Error subscribing to channel: private-$channelName. Error data: $data');
    });
  }

  // Bind an event to a callback function.
  // This method will listen for the specified event name (e.g., "new-message")
  // and execute the callback with the event data.
  void bindEvent(String eventName, void Function(dynamic) callback) {
    print("Binding event: $eventName");
    channel.bind(eventName, (event) {
      print("Event '$eventName' received: ${event?.data}");
      callback(event?.data);
    });
  }

  // Disconnect from Pusher
  void disconnect() {
    print("Disconnecting from Pusher...");
    pusher.disconnect();
  }

  // Unsubscribe from a channel
  void unsubscribe(String channelName) {
    print("Unsubscribing from channel: private-$channelName");
    pusher.unsubscribe('private-$channelName');
  }
}
