import 'package:twilio_programmable_video/twilio_programmable_video.dart';
import 'package:feeling_sync_chat/constant/api_constant.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class TwilioService {
  static const String baseUrl = '${ApiConstants.baseUrl}/api/get-twilio-token';

  Future<String> getTwilioToken() async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/get-twilio-token'),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body)['token'];
    } else {
      throw Exception('Failed to get Twilio token');
    }
  }

  Future<Room> connectToRoom(String token, String roomName) async {
    try {
      var connectOptions = ConnectOptions(
        token,
        roomName: roomName,
        preferredAudioCodecs: [OpusCodec()],
        preferredVideoCodecs: [H264Codec()],
        enableDominantSpeaker: true,
      );

      return await TwilioProgrammableVideo.connect(connectOptions);
    } catch (e) {
      throw Exception('Failed to connect to room: $e');
    }
  }
}
