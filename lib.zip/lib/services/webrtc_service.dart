import 'package:flutter_webrtc/flutter_webrtc.dart';

class WebRTCService {
  RTCPeerConnection? peerConnection;
  MediaStream? localStream;
  final RTCVideoRenderer localVideoRenderer = RTCVideoRenderer();
  final RTCVideoRenderer remoteVideoRenderer = RTCVideoRenderer();
  Function? onSignalingStateChange;

  Future<void> initialize() async {
    try {
      await localVideoRenderer.initialize();
      await remoteVideoRenderer.initialize();

      final Map<String, dynamic> mediaConstraints = {
        'audio': true,
        'video': {
          'mandatory': {
            'minWidth': '640',
            'minHeight': '480',
            'minFrameRate': '30',
          },
          'facingMode': 'user',
          'optional': [],
        }
      };

      localStream = await navigator.mediaDevices.getUserMedia(mediaConstraints);
      if (localStream != null) {
        localVideoRenderer.srcObject = localStream;
      } else {
        throw Exception('Failed to get local stream');
      }
    } catch (e) {
      print('Error in WebRTCService initialize: $e');
      throw e;
    }
  }

  void set onSignalingChange(Function callback) {
    onSignalingStateChange = callback;
  }

  Future<void> initializePeerConnection() async {
    await createPeerConnectionInstance();
  }

  Future<void> createOffer() async {
    if (peerConnection != null) {
      RTCSessionDescription offer = await peerConnection!.createOffer();
      await peerConnection!.setLocalDescription(offer);
    }
  }

  Future<void> createAnswer() async {
    if (peerConnection != null) {
      try {
        RTCSessionDescription answer = await peerConnection!.createAnswer();
        await peerConnection!.setLocalDescription(answer);
      } catch (e) {
        print('Error creating answer: $e');
      }
    } else {
      print('PeerConnection is null, cannot create answer');
    }
  }

  Future<void> createPeerConnectionInstance() async {
    final Map<String, dynamic> configuration = {
      'iceServers': [
        {
          'urls': [
            'stun:stun1.l.google.com:19302',
            'stun:stun2.l.google.com:19302'
          ]
        }
      ]
    };

    peerConnection = await createPeerConnection(configuration);

    if (peerConnection == null) {
      print("Failed to create PeerConnection");
      return;
    }

    if (localStream != null) {
      for (var track in localStream!.getTracks()) {
        peerConnection?.addTrack(track, localStream!);
      }
    }

    peerConnection?.onTrack = (RTCTrackEvent event) {
      if (event.streams.isNotEmpty) {
        remoteVideoRenderer.srcObject = event.streams[0];
      }
    };
  }

  Future<void> handleRemoteDescription(Map<String, dynamic> remoteDescription) async {
    if (peerConnection != null) {
      await peerConnection!.setRemoteDescription(
        RTCSessionDescription(
          remoteDescription['sdp'],
          remoteDescription['type'],
        ),
      );
    }
  }

  void dispose() {
    localStream?.getTracks().forEach((track) => track.stop());
    localStream?.dispose();
    localVideoRenderer.dispose();
    remoteVideoRenderer.dispose();
    peerConnection?.dispose();
  }
}
