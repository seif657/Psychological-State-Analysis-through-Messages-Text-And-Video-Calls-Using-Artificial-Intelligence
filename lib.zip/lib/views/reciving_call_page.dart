import 'package:feeling_sync_chat/controllers/receving_call_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ReceivingCallPage extends StatelessWidget {
  final ReceivingCallController controller = Get.put(ReceivingCallController());
  final String callerId;
  final String callerName;
  final String callId;
  final String callType;

  ReceivingCallPage({
    required this.callerId,
    required this.callerName,
    required this.callId,
    required this.callType,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black87,
      body: SafeArea(
        child: Obx(() => Stack(
          children: [
            // Caller info
            Positioned(
              top: 100,
              left: 0,
              right: 0,
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 50,
                    child: Text(
                      callerName[0].toUpperCase(),
                      style: TextStyle(fontSize: 40),
                    ),
                  ),
                  SizedBox(height: 20),
                  Text(
                    callerName,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Incoming ${callType} call...',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
            
            // Call controls
            Positioned(
              bottom: 50,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.red,
                    child: IconButton(
                      icon: Icon(Icons.call_end, color: Colors.white),
                      onPressed: () {
                        controller.rejectCall(callId);
                        Get.back();
                      },
                    ),
                  ),
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.green,
                    child: IconButton(
                      icon: Icon(Icons.call, color: Colors.white),
                      onPressed: () {
                        controller.acceptCall(callId);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        )),
      ),
    );
  }
}
