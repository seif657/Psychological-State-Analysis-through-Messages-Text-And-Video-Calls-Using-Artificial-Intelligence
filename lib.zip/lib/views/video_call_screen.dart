import 'package:twilio_programmable_video/twilio_programmable_video.dart';
import 'package:feeling_sync_chat/services/twillio_service.dart';
import 'package:flutter/material.dart';

class VideoCallScreen extends StatefulWidget {
  @override
  _VideoCallScreenState createState() => _VideoCallScreenState();
}

class _VideoCallScreenState extends State<VideoCallScreen> {
  final TwilioService _twilioService = TwilioService();
  Room? _room;
  
  Future<void> _joinRoom() async {
    try {
      final token = await _twilioService.getTwilioToken();
      final room = await _twilioService.connectToRoom(token, 'my-room');
      setState(() => _room = room);
    } catch (e) {
      print('Error joining room: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Video Call')),
      body: Column(
        children: [
          if (_room != null)
            Expanded(
              child: Container(
                // This will be your video container
                color: Colors.black,
              ),
            ),
          ElevatedButton(
            onPressed: _joinRoom,
            child: Text('Join Room'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _room?.disconnect();
    super.dispose();
  }
}
